<?php

require "config/conex.php";

$cod = $_POST["cod"];
$cantidad = $_POST["txt_cantidad"];
$valor = $_POST["txt_valor"];
$total = $cantidad * $valor;


$sql="UPDATE ventas(cantidad=$cantidad, valor=$valor, total=$total) where id=$cod;

if($dbh->query(sql))
{
           echo "Datos actualizados";
}else{
           echo "Error actualizado";
}

?>
