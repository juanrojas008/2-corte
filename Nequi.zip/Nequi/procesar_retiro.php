<?php
//1 paso 
require "config.conex.php";

//2 paso capturar variables
$valor = $_POST ["txt_valor"];
$id_logueado = 10;

//3 paso: Armar el sql




?>