<?php
require "config/conex.php";

$tipo = $_POST['tipo'];
$cantidad = $_POST['cantidad'];
$aplica_descuento = $_POST['aplica_descuento'];
  
if ($tipo == "1") {
    $total1 = $cantidad * 6000;
} else if ($tipo == "2") {
    $total1 = $cantidad * 8000;
} else if ($tipo == "3") {
    $total1 = $cantidad * 10000;
}

if ($aplica_descuento == "1") {
    $descuento = $total1 * 0.05;
    $total = $total1 - $descuento;
} else if ($aplica_descuento == "2") {
    $total = $total1;
}

$sql = "INSERT INTO parcial2 (tipo, cantidad, aplica_descuento, valor_venta) VALUES ('".$tipo."', '".$cantidad."', '".$aplica_descuento."', '".$total."')";

if($dbh->query($sql)){
    echo "Se ha registrado correctamente el producto";
} else {
    echo "Error al registrar el producto";
}


