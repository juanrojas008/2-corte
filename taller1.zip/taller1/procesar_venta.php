<?php
    $nombre = $_POST['txt_nombre'];
    $estrato = $_POST['estrato'];
    $cantidad = $_POST['txt_number'];
    $precio = 1500;

    // Si el estrato es 0, 1 o 2, el primer almuerzo es gratis
    if ($estrato == 0 || $estrato == 1 || $estrato == 2) {
        $cantidad -= 1;
    }

    // Asegurar que no haya valores negativos
    $cantidad = max(0, $cantidad);

    $total = $cantidad * $precio;

    echo "SEÑOR $nombre, usted debe pagar: $$total pesos.";

?>